//write a java program to find the operating system of the device.1

import java.net.InetAddress;
import java.net.UnknownHostException;

public class GetOperatingSystem {

    public static void main(String[] args) {
        String osName = System.getProperty("os.name");
        String osArch = System.getProperty("os.arch");
        String osVersion = System.getProperty("os.version");

        System.out.println("Basic system properties:");
        System.out.println("  OS Name:     " + osName);
        System.out.println("  OS Arch:     " + osArch);
        System.out.println("  OS Version:  " + osVersion);

        System.out.println("\nGathering additional clues...");
        String hostname = "";
        try {
            hostname = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        String domainName = hostname.substring(hostname.indexOf('.') + 1);
        System.out.println("  Hostname:    " + hostname);
        System.out.println("  Domain name: " + domainName); // Potential clue for corporate environments

        // TODO: Add more sophisticated techniques for refining OS identification (e.g., environment variables, specific API calls)
    }
}
