import org.savarese.vserv.tcpip.arp.ARP;
import org.savarese.vserv.tcpip.arp.ARPRequest;
import org.savarese.vserv.tcpip.arp.ARPPacket;
import org.savarese.vserv.tcpip.arp.ARPResponse;
import org.savarese.vserv.tcpip.arp.RawSocketARP;
import org.savarese.vserv.tcpip.arp.spi.ARPProtocol;
import org.savarese.vserv.tcpip.arp.spi.ARPTable;
import org.savarese.vserv.tcpip.arp.spi.DefaultARPTable;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;

public class LANDeviceScanner {

    public static void main(String[] args) {
        try {
            scanLANDevices();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void scanLANDevices() throws IOException {
        ARPProtocol<InetAddress> arpProtocol = new ARP();
        ARPTable<InetAddress> arpTable = new DefaultARPTable<>();

        // Choose the network interface for scanning
        NetworkInterface networkInterface = NetworkInterface.getByName("eth0");

        RawSocketARP<InetAddress> rawSocketARP = new RawSocketARP<>(arpTable, arpProtocol, networkInterface);
        rawSocketARP.open();

        // Get the local IP address
        InetAddress localAddress = InetAddress.getLocalHost();

        // Send ARP request to get the ARP table entries
        ARPRequest<InetAddress> arpRequest = new ARPRequest<>(localAddress, localAddress);
        ARPPacket<InetAddress> arpPacket = new ARPPacket<>(arpRequest);

        rawSocketARP.send(arpPacket);

        // Wait for ARP responses
        try {
            Thread.sleep(2000); // Adjust the wait time as needed
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Display the ARP table entries
        for (ARPResponse<InetAddress> response : arpTable.values()) {
            System.out.println("IP Address: " + response.getProtocolAddress() + ", MAC Address: " + response.getHardwareAddress());
        }

        rawSocketARP.close();
    }
}
