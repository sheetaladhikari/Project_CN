import java.net.*;
import java.util.*;
public class LANDeviceFinder {

    public static void main(String[] args) throws Exception {
        List<NetworkInterface> networkInterfaces = getAllNetworkInterfaces();

        for (NetworkInterface networkInterface : networkInterfaces) {
            if (!networkInterface.isUp() || networkInterface.isLoopback()) {
                continue; // Skip inactive or loopback interfaces
            }

            System.out.println("Interface: " + networkInterface.getName());

            byte[] mac = networkInterface.getHardwareAddress();
            if (mac == null) {
                System.out.println("MAC address not available for interface: " + networkInterface.getName());
                continue;
            }

            System.out.println("MAC Address: " + getMacAddress(mac));

            Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();
            while (addresses.hasMoreElements()) {
                InetAddress address = addresses.nextElement();

                if (address instanceof Inet4Address) { // Focus on IPv4 addresses
                    String hostAddress = address.getHostAddress();
                    String hostName = address.getHostName();

                    System.out.println(" Device: " + hostName + " (" + hostAddress + ")");
                }
            }
        }
    }

    private static List<NetworkInterface> getAllNetworkInterfaces() throws SocketException {
        List<NetworkInterface> interfaces = new ArrayList<>();
        Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();

        while (networkInterfaces.hasMoreElements()) {
            NetworkInterface networkInterface = networkInterfaces.nextElement();
            interfaces.add(networkInterface);
        }

        return interfaces;
    }

    private static String getMacAddress(byte[] mac) {
        StringBuilder sb = new StringBuilder();
        for (byte b : mac) {
            sb.append(String.format("%02X:", b));
        }
        return sb.substring(0, sb.length() - 1); // Remove trailing colon
    }
}